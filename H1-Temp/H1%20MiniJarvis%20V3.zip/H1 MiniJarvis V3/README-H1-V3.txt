H1 MiniJarvis V3

Contenido:
00-Guion-docente-H1-MiniJarvis-V3.docx
01-Presentaciones-H1-V3/  (10 PPTX editables, longitud variable y notas sincronizadas)
02-Moodle-H1-V3/         (10 páginas de sesión actualizadas)
03-Drive-H1-V3/          (diario, Scrum, Sites, entrega y tarea H1)
04-Auditoria/             (comprobación Moodle/Drive)

HEXA: S206 Activar · S207-S208 Investigar · S209 Idear · S210 Planificar · S211-S213 Ejecutar · S214-S215 Comunicar.
