# H5 — Agente extensible, clean code y patrones iniciales

## Ficha para el alumnado

---

## 1. Reto

Vais a mejorar MiniJarvis para que sea más fácil añadir herramientas o comandos nuevos.

No se trata de hacer el código “más complicado”, sino más claro, mantenible y fácil de ampliar.

---

## 2. Qué debe tener H5

```text
[x] Herramientas o comandos internos separados.
[x] Refactorización explicada.
[x] Evidencia de Git, rama, commits, PR o revisión equivalente.
[x] Revisión de código.
[x] Decisión sobre patrón: usado o descartado con motivo.
[x] Comparación Java ↔ Python.
```

---

## 3. Qué NO entra todavía

```text
[ ] Plugins reales.
[ ] Frameworks externos.
[ ] Persistencia en ficheros.
[ ] Base de datos.
[ ] IA real.
[ ] Patrones usados porque sí.
```

---

## 4. Entregables

```text
h5-extensible-clean-code-patrones/
├── README
├── src/
│   ├── Main.java
│   ├── Agent.java
│   ├── Memory.java
│   ├── Tool.java
│   └── herramientas...
└── docs/
    ├── informe-refactorizacion-h5
    ├── evidencia-git-h5
    ├── revision-codigo-h5
    ├── registro-patron-h5
    ├── comparacion-java-python-h5
    ├── portfolio-h5
    ├── registro-ia
    └── defensa-h5
```

---

## 5. Preguntas de defensa

```text
¿Qué problema tenía el código antes?
¿Qué refactorización hiciste?
¿Qué herramienta nueva añadiste?
¿Por qué ahora es más fácil añadir comandos?
¿Qué patrón usaste o descartaste?
¿Qué evidencia hay en Git o en la revisión?
¿Qué diferencia hay entre interfaces Java y duck typing en Python?
```
