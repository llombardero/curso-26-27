# H6 — Agente persistente y trazable

## Ficha para el alumnado

---

## 1. Reto

Vais a hacer que MiniJarvis pueda guardar y recuperar información entre ejecuciones.

También crearéis un historial simple y revisaréis seguridad: nada de secretos ni datos personales reales.

---

## 2. Qué debe tener H6

```text
[x] Guardar recuerdos en fichero.
[x] Recuperar recuerdos al iniciar o consultar.
[x] Crear logs o historial simple.
[x] README reproducible.
[x] Pruebas de persistencia.
[x] Registro de seguridad.
[x] Comparación Java ↔ Python.
```

---

## 3. Qué NO entra todavía

```text
[ ] API keys reales.
[ ] .env real en el repositorio.
[ ] Datos personales reales.
[ ] Base de datos compleja obligatoria.
[ ] IA real obligatoria.
```

---

## 4. Entregables

```text
h6-persistente-trazable/
├── README.md
├── src/
├── data/        # solo datos ficticios necesarios
└── logs/        # anonimizados; sin secretos
```

El README integra pruebas de persistencia, seguridad, logs, incidencias y reproducción. No hay portfolio H6 ni registro IA separado; diario/Scrum se actualizan solo si el uso fue significativo.

---

## 5. Preguntas de defensa

```text
¿Dónde se guarda la información?
¿Qué ocurre si el fichero no existe?
¿Cómo puedo ejecutar tu proyecto desde cero?
¿Qué datos no deberías guardar?
¿Cómo sabes que persiste entre ejecuciones?
¿Qué diferencia hay entre ficheros en Java y Python?
```
