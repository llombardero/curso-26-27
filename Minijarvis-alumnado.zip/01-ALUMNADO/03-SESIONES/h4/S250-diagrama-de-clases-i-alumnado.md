# Sesión 250 — Ficha de trabajo del alumnado

## Diagrama de clases I

| Hoy vas a… | Debe quedar… |
|---|---|
| Representar diseño en UML básico. | `docs/diagrama-clases-h4` versión inicial. |

**Tiempo previsto:** 45 minutos.  
**Hito:** H4.

## Material que necesitas

- Un ordenador por estudiante o pareja, con JDK e IntelliJ disponibles y el proyecto del hito accesible.
- Pizarra o una hoja reutilizable para bosquejar antes de modificar el proyecto.

## Trabajo de hoy

1. Lee el objetivo y escribe con tus palabras qué debe quedar terminado.
2. Atiende al ejemplo breve y anota una predicción, duda o decisión.
3. Realiza esta tarea: **Dibujar diagrama de clases actual.**
4. Comprueba el resultado con una prueba observable; no basta con decir “funciona”.
5. Guarda o entrega la evidencia indicada y prepárate para explicarla.

## Registro breve

**Qué intento conseguir:**  
................................................................................

**Decisión o hipótesis que probaré:**  
................................................................................

**Prueba que he realizado y resultado:**  
................................................................................

**Bloqueo encontrado y siguiente paso:**  
................................................................................

## Evidencia mínima antes de salir

- [ ] He producido o actualizado: **`docs/diagrama-clases-h4` versión inicial.**
- [ ] Puedo señalar dónde está.
- [ ] Puedo explicar una decisión tomada.
- [ ] Puedo mostrar una prueba o comprobación.
- [ ] He registrado mi aportación individual si el trabajo era de equipo.

## Seguridad y uso de IA

- Trabaja únicamente con datos ficticios.
- No escribas contraseñas, tokens, claves API ni datos personales.
- Si utilizas IA en un uso permitido, registra qué pediste, qué recibiste, qué cambiaste y cómo lo comprobaste.
- Los ejemplos de Laura solo se consultan después del intento propio.

## Si te bloqueas

1. Copia el mensaje exacto o describe qué observas.
2. Indica qué esperabas que ocurriera.
3. Reduce el problema a una prueba pequeña.
4. Pide ayuda mostrando esos tres datos; no pidas directamente la solución completa.

## Cierre

Responde sin copiar: **Revisar si el diagrama coincide con el código.**

Respuesta:  
................................................................................

La sesión está completada cuando la evidencia existe, se ha comprobado y puedes defenderla brevemente.
