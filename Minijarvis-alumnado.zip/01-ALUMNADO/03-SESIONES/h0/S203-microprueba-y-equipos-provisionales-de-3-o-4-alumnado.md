# Sesión 203 — Ficha de trabajo del alumnado

## Composición HADA, equipo provisional y funciones para la torre

| Hoy vais a… | Debe quedar… |
|---|---|
| Analizar cómo se combinan las preferencias del equipo, compensar capacidades menos representadas y preparar el sprint de la torre. | Mapa de composición, funciones justificadas, regla de participación, backlog y definición de terminado. |

**Tiempo previsto:** 45 minutos.  
**Hito:** H0.

---

## 1. Reglas de esta sesión

- El equipo es provisional y se revisará después de la torre.
- Nadie tiene que publicar sus puntuaciones HADA.
- Cada persona sí explica una aportación que quiere ofrecer y una capacidad que quiere practicar.
- Un perfil HADA no asigna automáticamente una función.
- Tener una función no significa mandar.
- Todas las personas participarán en diseño, construcción, prueba y explicación.

---

## Microprueba materializada: primero individual, después en pareja o trío

Esta microprueba es diagnóstica y no calificable. Se realiza antes de acordar las funciones del equipo.

### Fase individual — 4 minutos

Sin consultar a otra persona, escribe:

1. tres tareas necesarias para preparar la torre;
2. una restricción que habría que comprobar;
3. una prueba pequeña anterior a la entrega;
4. un bloqueo probable y cómo lo harías visible.

### Fase en pareja o trío aleatorio — 6 minutos

Comparad las propuestas individuales y entregad una síntesis con:

- seis tareas ordenadas por prioridad;
- dos alternativas de diseño;
- una definición inicial de terminado;
- una prueba observable;
- una decisión que identifique una aportación ajena incorporada.

Conserva tu respuesta individual en el diario. La pareja o trío entrega una única síntesis. El equipo definitivo puede reutilizarla después, pero no copiarla sin revisarla.

---

## 2. Presentación individual al equipo

Cada persona completa y comparte lo que considere necesario:

| Integrante | Una aportación que puede iniciar | Una capacidad o función que quiere practicar | Condición que ayuda a participar |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
| | | | |

No escribáis datos personales sensibles ni puntuaciones sin consentimiento.

---

## 3. Mapa HADA del equipo

No copiéis números individuales. Acordad una apreciación global:

| Tendencia | Presencia clara | Presencia parcial | Necesita compensación | Evidencia o explicación breve |
|---|:---:|:---:|:---:|---|
| Gestor: avance y objetivos | | | | |
| Colaborador: cooperación y clima | | | | |
| Desarrollador: ideas y alternativas | | | | |
| Analista: precisión y comprobación | | | | |

**Fortaleza probable del equipo:**  
................................................................................

**Capacidad que puede quedar menos representada:**  
................................................................................

**Riesgo que aparecería si no la compensamos:**  
................................................................................

---

## 4. Funciones operativas para la torre

Estas funciones son una adaptación educativa. No son cuatro roles oficiales de Scrum.

| Función | Qué debe hacer visible | Qué no significa |
|---|---|---|
| Valor y backlog | Objetivo, prioridades, tareas, estados y definición de terminado. | Dar órdenes o decidir sin el equipo. |
| Facilitación y tiempo | Turnos, participación, bloqueos y avisos temporales. | Ser jefe o controlar a las personas. |
| Calidad y pruebas | Restricciones, pruebas tempranas, medición y resultados. | Ser la única persona que comprueba. |
| Evidencias y comunicación | Decisiones, cambios, aportaciones y explicación final. | Escribir en solitario o ser siempre portavoz. |

Todo el equipo construye y puede explicar el resultado.

### Relación orientativa con HADA

| Tendencia | Funciones que pueden resultar naturales | Funciones que también conviene practicar |
|---|---|---|
| Gestor | Avance, backlog, tiempo. | Escucha, mediación, revisión. |
| Colaborador | Facilitación, mediación, presentación. | Priorización y crítica razonada. |
| Desarrollador | Ideas, alternativas y prototipado. | Cierre, prueba y documentación. |
| Analista | Calidad, prueba, documentación y crítica. | Experimentación y comunicación. |

La tabla orienta una conversación; no decide por vosotros.

---

## 5. Acuerdo de funciones

| Función | Responsable inicial | Sustituto si falta | Razón basada en aporte o aprendizaje | Conducta observable durante la torre |
|---|---|---|---|---|
| Valor y backlog | | | | |
| Facilitación y tiempo | | | | |
| Calidad y pruebas | | | | |
| Evidencias y comunicación | | | | |

Si sois tres personas, indicad quién combina temporalmente dos funciones:  
................................................................................

Comprobación:

- [ ] Al menos una persona practicará una función que no coincide con su preferencia más evidente.
- [ ] Ninguna función excluye a los demás de construir o decidir.
- [ ] Sabemos qué conducta permitirá comprobar cada función.

---

## 6. Regla de participación

Completad con una conducta observable:

```text
Evitaremos que una sola persona diseñe o construya toda la torre mediante esta regla:

..............................................................................
```

Ejemplos que podéis valorar después de vuestro intento:

- limitar a dos las tareas simultáneas;
- repartir la manipulación del material;
- escuchar dos propuestas antes de elegir;
- elegir al azar quién explica una decisión.

---

## 7. Reto que prepararemos

En la próxima sesión trabajaréis en dos ciclos:

```text
Ciclo 1: 6 hojas A4 reutilizadas, tijeras y regla, sin conectores.
Ciclo 2: podréis solicitar de forma justificada hasta 4 hojas más,
1 cartulina A4 usada, 6 clips, 4 gomas, 100 cm de cordel y perforadora.
```

Antes de recibir material del ciclo 2 registraréis:

```text
Problema observado → material solicitado → cambio previsto → prueba esperada
```

Debéis crear una torre autoportante que:

- use solamente el material entregado;
- apoye toda su base dentro de 25 × 25 cm;
- sostenga una carga común aproximada de 50 g durante 60 segundos;
- pueda medirse desde la mesa hasta su punto más alto con la carga colocada;
- deje evidencia de decisiones, pruebas y mejora.

Hoy no se construye todavía. Hoy se prepara el trabajo.

---

## 8. Backlog inicial de la torre

Escribid al menos seis tareas. Deben poder empezar, terminar y comprobarse.

| Prioridad | Tarea | Función que vigilará que no se olvide | Criterio para marcarla Hecho | Estado inicial |
|---:|---|---|---|---|
| 1 | | | | Pendiente |
| 2 | | | | Pendiente |
| 3 | | | | Pendiente |
| 4 | | | | Pendiente |
| 5 | | | | Pendiente |
| 6 | | | | Pendiente |
| 7 | | | | Pendiente |
| 8 | | | | Pendiente |

Comprobad si vuestro backlog incluye:

- comprender restricciones;
- generar alternativas;
- elegir una estrategia;
- realizar una prueba pequeña;
- construir o integrar;
- probar estabilidad;
- medir;
- preparar evidencias y review.

No es obligatorio usar estas palabras, pero ninguna necesidad importante debe quedar olvidada.

---

## 9. Definición de terminado y bloqueo

**La torre estará terminada cuando:**  
................................................................................

................................................................................

**Un bloqueo probable es:**  
................................................................................

**Lo haremos visible mediante:**  
................................................................................

---

## 10. Defensa breve del diseño del equipo

Una persona elegida al azar debe poder explicar:

1. qué capacidad quiere compensar el equipo;
2. qué función se encargará de hacerla visible;
3. qué conducta demostrará que la función se ejerció;
4. qué criterio permitirá afirmar que la torre está terminada.

Preparad la explicación para que no dependa de una única persona.

---

## 11. Cierre individual

Completa sin copiar:

**Mi responsabilidad inicial:**  
................................................................................

**La conducta que demostrará que la cumplo:**  
................................................................................

**Una tarea compartida en la que también participaré:**  
................................................................................

**Aceptaré revisar la función después de la torre si observamos que:**  
................................................................................

---

## 12. Evidencia mínima antes de salir

- [ ] El equipo ha identificado una fortaleza y una capacidad por compensar.
- [ ] Las cuatro funciones están cubiertas.
- [ ] Cada función tiene responsable, sustituto y conducta observable.
- [ ] Existe una regla concreta de participación.
- [ ] El backlog contiene al menos seis tareas.
- [ ] La definición de terminado incluye base, carga, estabilidad durante 60 segundos y altura con carga.
- [ ] Cada persona ha registrado su aportación y aprendizaje.
- [ ] Entendemos que composición y funciones son provisionales.

---

## Fuente

Los perfiles y la compensación de capacidades mediante funciones se basan en:

> Tknika, Centro de Investigación en FP Euskadi. *HADA — Análisis de la composición del equipo*, 2019.

Las cuatro funciones utilizadas en la torre son una adaptación educativa de H0.
