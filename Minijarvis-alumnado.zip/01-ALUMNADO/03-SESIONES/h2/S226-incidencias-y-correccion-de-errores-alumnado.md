# Sesión 226 — Ficha de trabajo del alumnado

## Incidencias y corrección de errores

| Hoy vas a… | Debe quedar… |
|---|---|
| Documentar un fallo real y su solución. | README, sección «Incidencias significativas». |

**Tiempo previsto:** 45 minutos.  
**Hito:** H2.

## Material que necesitas

- Un ordenador por estudiante o pareja, con JDK e IntelliJ disponibles y el proyecto del hito accesible.

## Trabajo de hoy

1. Lee el objetivo y escribe con tus palabras qué debe quedar terminado.
2. Atiende al ejemplo breve y anota una predicción, duda o decisión.
3. Realiza esta tarea: **Registrar un error encontrado, causa, solución y prueba posterior.**
4. Comprueba el resultado con una prueba observable; no basta con decir “funciona”.
5. Guarda o entrega la evidencia indicada y prepárate para explicarla.

## Comprobación práctica

Comprueba **el resultado observable de la actividad** en su fuente canónica y prepárate para explicarlo. Registra en diario o Scrum únicamente si hubo un aprendizaje, decisión, bloqueo o uso de IA significativo.


## Seguridad y uso de IA

- Trabaja únicamente con datos ficticios.
- No escribas contraseñas, tokens, claves API ni datos personales.
- Si utilizas IA en un uso permitido, registra qué pediste, qué recibiste, qué cambiaste y cómo lo comprobaste.
- Los ejemplos de Laura solo se consultan después del intento propio.

## Si te bloqueas

1. Copia el mensaje exacto o describe qué observas.
2. Indica qué esperabas que ocurriera.
3. Reduce el problema a una prueba pequeña.
4. Pide ayuda mostrando esos tres datos; no pidas directamente la solución completa.

## Cierre

Responde sin copiar: **Compartir una incidencia útil con la clase.**

Respuesta:  
................................................................................

La sesión está completada cuando la evidencia existe, se ha comprobado y puedes defenderla brevemente.
