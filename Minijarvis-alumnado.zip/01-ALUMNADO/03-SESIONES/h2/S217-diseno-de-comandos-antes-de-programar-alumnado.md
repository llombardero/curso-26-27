# Sesión 217 — Ficha de trabajo del alumnado

## Diseño de comandos antes de programar

| Hoy vas a… | Debe quedar… |
|---|---|
| Definir comportamiento comprobable. | Tabla de comandos con respuesta esperada. |

**Tiempo previsto:** 45 minutos.  
**Hito:** H2.
**Modalidad:** Equipo.

## Material que necesitas

- Un ordenador por estudiante o pareja, con JDK e IntelliJ disponibles y el proyecto del hito accesible.
- Pizarra o una hoja reutilizable para bosquejar antes de modificar el proyecto.

## Trabajo de hoy

1. Lee el objetivo y escribe con tus palabras qué debe quedar terminado.
2. Atiende al ejemplo breve y anota una predicción, duda o decisión.
3. Realiza esta tarea: **Completar tabla de comandos: `ayuda`, `saluda`, `estado`, `salir`, `otro`.**
4. Comprueba el resultado con una prueba observable; no basta con decir “funciona”.
5. Guarda o entrega la evidencia indicada y prepárate para explicarla.

## Comprobación práctica

Comprueba **el resultado observable de la actividad** en su fuente canónica y prepárate para explicarlo. Registra en diario o Scrum únicamente si hubo un aprendizaje, decisión, bloqueo o uso de IA significativo.


## Si te bloqueas

1. Copia el mensaje exacto o describe qué observas.
2. Indica qué esperabas que ocurriera.
3. Reduce el problema a una prueba pequeña.
4. Pide ayuda mostrando esos tres datos; no pidas directamente la solución completa.

## Cierre

Responde sin copiar: **Revisar si todos los comandos tienen criterio de aceptación.**

Respuesta:  
................................................................................

La sesión está completada cuando la evidencia existe, se ha comprobado y puedes defenderla brevemente.
