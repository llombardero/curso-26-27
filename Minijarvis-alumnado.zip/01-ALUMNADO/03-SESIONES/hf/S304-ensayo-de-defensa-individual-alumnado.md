# HF.8 — Ensayo de defensa individual

## Ensayo de defensa individual

| Hoy vas a… | Debe quedar… |
|---|---|
| Preparar defensa final sin memorizar. | Ensayo individual con producto, prueba observable y decisión explicada. |

**Tiempo previsto:** 45 minutos.  
**Hito:** HF.
**Modalidad:** Parejas.

## Material que necesitas

- Un ordenador por estudiante o pareja, con JDK e IntelliJ disponibles y el proyecto del hito accesible.
- Proyector solo si habrá demostración colectiva; la defensa puede realizarse directamente en el equipo.

## Organización del trabajo

Ensayad por parejas, alternando defensa y preguntas; cada persona termina identificando sus propias mejoras antes de la defensa evaluativa.

## Trabajo de hoy

1. Lee el objetivo y escribe con tus palabras qué debe quedar terminado.
2. Atiende al ejemplo breve y anota una predicción, duda o decisión.
3. Realiza esta tarea: **Simulación de preguntas por parejas o tríos.**
4. Comprueba el resultado con una prueba observable; no basta con decir “funciona”.
5. Guarda o entrega la evidencia indicada y prepárate para explicarla.

## Comprobación práctica

Comprueba **el resultado observable de la actividad** en su fuente canónica y prepárate para explicarlo. Registra en diario o Scrum únicamente si hubo un aprendizaje, decisión, bloqueo o uso de IA significativo.


## Si te bloqueas

1. Copia el mensaje exacto o describe qué observas.
2. Indica qué esperabas que ocurriera.
3. Reduce el problema a una prueba pequeña.
4. Pide ayuda mostrando esos tres datos; no pidas directamente la solución completa.

## Cierre

Responde sin copiar: **Cada alumno anota tres preguntas que debe preparar mejor.**

Respuesta:  
................................................................................

La sesión está completada cuando la evidencia existe, se ha comprobado y puedes defenderla brevemente.
