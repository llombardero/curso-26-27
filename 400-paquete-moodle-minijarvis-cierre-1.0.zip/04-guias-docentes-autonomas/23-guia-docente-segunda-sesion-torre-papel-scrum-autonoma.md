# Guía docente completa — Segunda sesión: Torre de papel y Scrum de aula

<!-- HEXA-CICLO-COMPLETO-POR-HITO:START -->

## Ciclo HEXA obligatorio del reto H0

**Reto del hito:** Organizar y completar una torre de papel mediante un sprint Scrum y transferir lo aprendido a MiniJarvis.

La secuencia de sesiones constituye un único reto de hito. Las actividades HEXA breves de cada sesión son microciclos, pero no sustituyen este ciclo completo del hito.

| Fase | Pregunta que guía la fase | Acción del profesorado | Acción y evidencia del alumnado |
|---|---|---|---|
| **H — Hecho / reto** | ¿Qué problema real debemos resolver y con qué límites? | Presenta contexto, producto, restricciones, criterios y diagnóstico; no da todavía la solución completa. | Reformula el reto, identifica lo que sabe/no sabe y deja una ficha inicial con criterios de éxito. |
| **E — Exploración** | ¿Qué alternativas, hipótesis o pruebas iniciales ayudan a entenderlo? | Propone preguntas, ejemplos mínimos, casos y límites seguros. | Observa, compara, predice, prueba alternativas y registra decisiones o bloqueos. |
| **X — eXplicación** | ¿Qué conceptos permiten explicar lo observado y decidir con criterio? | Formaliza vocabulario, sintaxis, modelo mental, errores frecuentes, seguridad y criterios de calidad. | Explica con palabras propias, conecta teoría y exploración y corrige sus hipótesis. |
| **A — Aplicación** | ¿Cómo construimos, comprobamos, documentamos y defendemos la solución? | Desbloquea, exige pruebas y comprueba autoría y transferencia. | Implementa el producto, lo prueba, documenta evidencias, realiza review/defensa y propone mejora. |

### Temporalización mínima explícita

Primera sesión de 135 min para presentar el curso, introducir Scrum y realizar el diagnóstico; sesión siguiente de 90 min para aplicar Scrum en la torre. El resto de H0 se dedica a review, retrospectiva, contrato y transferencia a MiniJarvis. Los tiempos de fases se reservan dentro de las sesiones indicadas; los rangos pueden solaparse cuando una sesión cierra una fase y abre la siguiente.

| Fase | Reserva y momento recomendado | Puerta de salida |
|---|---|---|
| H | Presentación del curso y reto H0; 35 min de la primera sesión | Reto reformulado, límites y criterio de éxito visibles. |
| E | Scrum mínimo, autoevaluación y microprueba diagnóstica; 50 min de la primera sesión | Hipótesis, comparación, prueba inicial o decisiones justificadas. |
| X | Explicación de sprint, backlog, roles, prueba, review y retrospectiva; 30 min integrados | Explicación individual breve y conexión con el producto. |
| A | Equipos provisionales, torre, prueba, review, retrospectiva y transferencia; 90 min más cierre de H0 | Producto comprobado, documentación, defensa y mejora. |

**Expediente HEXA mínimo del hito:** ficha inicial, autoevaluación privada, microprueba, criterio de formación de equipos, backlog, torre comprobada, review, retrospectiva, revisión del equipo y aportación individual.

Regla de avance: puede haber prototipos durante E, pero no se considera completada A si faltan evidencias de H, E o X. Si una fase falta, se recupera esa fase y su evidencia; no se repite automáticamente todo el hito.

<!-- HEXA-CICLO-COMPLETO-POR-HITO:END -->


## Programación + Entornos de Desarrollo — 1.º DAW — Curso 2026/2027

Versión: cierre curricular 1.0 — julio 2026

Documento autónomo para uso del profesorado.

Este documento está diseñado para poder impartir la segunda sesión sin abrir ningún otro material.

---

## 1. Propósito de la sesión

Esta sesión continúa H0: aplica Scrum con los equipos provisionales formados mediante el diagnóstico de la sesión anterior.

El alumnado construirá una torre de papel siguiendo una dinámica simplificada de Scrum.

El objetivo principal no es hacer la torre más alta.

El objetivo real es que el alumnado experimente:

```text
- trabajo en equipo;
- roles;
- backlog;
- planificación;
- sprint;
- revisión del producto;
- retrospectiva;
- mejora continua;
- conexión entre una actividad física y un proyecto software.
```

Mensaje central de la sesión:

```text
Hoy no vamos a estudiar Scrum como teoría. Vamos a vivir un sprint corto y después vamos a extraer qué nos sirve para construir MiniJarvis.
```

---

## 2. Duración recomendada

Duración ideal:

```text
90 minutos = 2 periodos de 45 minutos
```

También se puede adaptar a:

```text
45 minutos: versión muy reducida.
135 minutos: versión ampliada con más reflexión y transferencia a MiniJarvis.
```

Las adaptaciones aparecen al final del documento.

---

## 3. Resultado esperado al terminar

Al finalizar la sesión, el alumnado debería poder explicar con sus palabras:

```text
1. Qué es un sprint.
2. Qué es un backlog.
3. Qué significa tener un rol en un equipo.
4. Qué es una review.
5. Qué es una retrospectiva.
6. Qué es un bloqueo.
7. Por qué un proyecto se mejora por iteraciones.
8. Qué relación hay entre la torre de papel y MiniJarvis.
```

No se espera todavía que dominen Scrum.

Sí se espera que hayan vivido una experiencia inicial de trabajo por sprint.

---

## 4. Material necesario

### Material por equipo

Recomendación para equipos de 3-4 personas:

```text
- 10 hojas de papel reciclado o folios.
- 50 cm de cinta adhesiva.
- 6-10 notas adhesivas o tarjetas pequeñas.
- 1 rotulador.
- 1 hoja de trabajo por equipo, que puede copiarse de este documento.
```

### Material común

```text
- Cronómetro visible.
- Pizarra.
- Regla o metro para medir torres.
- Espacio libre para construir.
- Cámara o móvil docente si se quieren fotografiar evidencias.
```

### Si no tienes notas adhesivas

Usa papel normal recortado o una tabla en el cuaderno.

### Si no tienes cinta adhesiva

Se puede hacer solo con papel, pero la actividad será más difícil. En ese caso, valora más el proceso que la estabilidad.

---

## 5. Preparación docente antes de clase

Antes de empezar:

```text
[ ] Revisar los equipos provisionales creados con autoevaluación, microprueba y observación.
[ ] Confirmar asistencia real y resolver ausencias manteniendo equipos de 3 o 4.
[ ] Evitar crear un equipo de 5 o dejar a una persona sola por comodidad.
[ ] Preparar la responsabilidad inicial de cada integrante; los roles rotarán.
[ ] No mostrar puntuaciones ni perfiles individuales.
[ ] Entregar exactamente los mismos materiales a todos los equipos.
[ ] Preparar cronómetro, regla y matriz de observación.
```

Si falta una persona: un equipo de cuatro puede quedar en tres. Si el reparto genera un equipo de dos, redistribuir una persona de un equipo de cuatro para obtener dos equipos de tres. No repetir el diagnóstico completo.

La torre funciona también como validación: la retrospectiva puede confirmar el equipo o justificar un ajuste pedagógico posterior.

## 6. Vocabulario mínimo que debes explicar tú

No hagas una clase larga de Scrum.

Explica solo esto:

### Sprint

```text
Periodo corto de trabajo con un objetivo concreto.
```

Ejemplo:

```text
Durante 20 minutos vuestro sprint será construir una torre estable.
```

### Backlog

```text
Lista de tareas que el equipo cree que debe hacer.
```

Ejemplo:

```text
Diseñar base, doblar columnas, probar estabilidad, preparar explicación.
```

### Rol

```text
Responsabilidad concreta dentro del equipo. Tener un rol no significa mandar.
```

### Review

```text
Momento para mostrar el producto y comprobar qué se ha conseguido.
```

### Retrospectiva

```text
Momento para pensar cómo ha trabajado el equipo y qué mejoraría.
```

### Bloqueo

```text
Problema que impide avanzar o ralentiza mucho el trabajo.
```

---

## 7. Qué NO debes explicar todavía

Evita entrar en:

```text
- Scrum Master profesional.
- Product Owner profesional.
- ceremonias Scrum completas.
- Jira, GitHub Projects o tableros complejos.
- teoría extensa de metodologías ágiles.
- manifiesto ágil completo.
```

Hoy basta con una experiencia práctica.

La teoría vendrá después, conectada a lo que hayan vivido.

---

## 8. Estructura global de la sesión de 90 minutos

| Fase | Tiempo | Producto |
|---|---:|---|
| 1. Entrada y conexión con sesión anterior | 5 min | Sentido de continuidad. |
| 2. Presentación del reto | 10 min | Reglas entendidas. |
| 3. Activación de equipos y responsabilidades | 10 min | Equipo confirmado y aportaciones declaradas. |
| 4. Backlog y planificación | 15 min | Lista inicial de tareas. |
| 5. Sprint de construcción | 20 min | Torre/prototipo. |
| 6. Review y medición | 10 min | Resultado visible. |
| 7. Retrospectiva | 15 min | Aprendizajes y mejoras. |
| 8. Transferencia a MiniJarvis y cierre | 5 min | Conexión con proyecto. |

---

## 9. Fase 1 — Entrada y conexión con la sesión anterior

Tiempo:

```text
5 minutos
```

### Guion docente literal

```text
En la sesión anterior vimos que este curso construiremos MiniJarvis por hitos.

Hoy vamos a practicar una forma de trabajar que nos servirá durante el proyecto: trabajar por sprint, con tareas, roles, revisión y mejora.

Lo haremos con una actividad sencilla: una torre de papel.
```

### Pregunta rápida al grupo

```text
¿Qué recordáis de la idea de trabajar por hitos?
```

Acepta 2-3 respuestas.

Cierre de esta fase:

```text
Perfecto. Hoy vamos a vivir un hito muy pequeño y muy rápido.
```

---

## 10. Fase 2 — Presentación del reto

Tiempo:

```text
10 minutos
```

### Guion docente literal

```text
El reto es construir una torre de papel lo más estable posible usando solo el material entregado.

La torre debe mantenerse en pie al menos 10 segundos sin tocarla.

Pero atención: no vamos a valorar solo la torre. También vamos a observar cómo os organizáis, cómo planificáis, cómo reaccionáis ante bloqueos y cómo mejoráis.
```

### Reglas del reto

Escribe o lee:

```text
1. La torre debe mantenerse en pie al menos 10 segundos sin tocarla.
2. Solo se puede usar el material entregado por el docente.
3. Antes de construir, el equipo debe crear un backlog con al menos 5 tareas.
4. Cada persona debe tener un rol inicial.
5. Durante el sprint, el equipo debe actualizar el estado de las tareas.
6. Al final habrá review y retrospectiva.
7. No gana necesariamente la torre más alta: también importa el proceso.
```

### Criterio de éxito

```text
Producto + proceso + comunicación + mejora
```

### Pregunta de comprobación

Antes de seguir, pregunta:

```text
¿Qué es más importante hoy: solo la altura o también cómo trabajamos?
```

Respuesta esperada:

```text
También cómo trabajamos.
```

---

## 11. Fase 3 — Activación de equipos y responsabilidades

Tiempo: 10 minutos. Los equipos ya llegan preparados; no se forman por amistad en este momento.

1. Anunciar la composición sin puntuaciones.
2. Recordar que es provisional hasta la retrospectiva.
3. Asignar responsabilidades iniciales:
   - facilitación y tiempo;
   - backlog y organización;
   - prototipo y construcción;
   - calidad, evidencias y defensa.
4. En equipos de tres, combinar backlog con evidencias o facilitación con tiempo.
5. Cada integrante completa oralmente: “Hoy aportaré...” y “Hoy practicaré...”.

Guion:

```text
Los equipos se han preparado para combinar habilidades y apoyos. Ningún resultado os encasilla. Todas las personas diseñan, construyen, prueban y explican; la responsabilidad indica qué debéis vigilar especialmente.
```

Producto: nombres, responsabilidad inicial, fortaleza aportada y habilidad que se practicará. No adjuntar las puntuaciones del cuestionario.

## 12. Fase 4 — Backlog y planificación

Tiempo:

```text
15 minutos
```

### Objetivo

Que el alumnado planifique antes de construir.

### Guion docente literal

```text
Todavía no podéis construir.

Primero tenéis que pensar qué tareas necesitáis hacer y escribir un backlog.

Una buena tarea empieza por un verbo y se puede terminar.
```

### Ejemplos de tareas

```text
- Analizar materiales.
- Diseñar la base.
- Doblar columnas.
- Reforzar unión central.
- Probar estabilidad.
- Medir altura.
- Preparar explicación final.
```

### Tareas poco útiles

```text
- Torre.
- Papel.
- Hacerlo.
- Cosas.
```

### Backlog mínimo

Cada equipo debe escribir al menos 5 tareas.

Plantilla:

| Nº | Tarea | Responsable | Estado inicial |
|---:|---|---|---|
| 1 | | | Pendiente |
| 2 | | | Pendiente |
| 3 | | | Pendiente |
| 4 | | | Pendiente |
| 5 | | | Pendiente |
| 6 | | | Pendiente |
| 7 | | | Pendiente |

### Estados posibles

```text
Pendiente
En curso
Hecho
Bloqueado
```

### Intervención docente si se bloquean

Pregunta:

```text
¿Qué tendría que pasar para que la torre se mantenga de pie 10 segundos?
```

O:

```text
¿Qué podéis probar antes de gastar todo el tiempo construyendo?
```

---

## 13. Fase 5 — Sprint de construcción

Tiempo:

```text
20 minutos
```

### Guion antes de empezar

```text
Ahora empieza el sprint.

Durante 20 minutos podéis construir, probar, cambiar y actualizar vuestro backlog.

Recordad: si aparece un bloqueo, no lo ocultéis. Anotadlo.

Cuando termine el tiempo, se deja de construir.
```

### Durante el sprint, el docente observa

No resuelvas tú el diseño de la torre.

Observa:

| Observación | Qué puede indicar |
|---|---|
| Construyen sin backlog | Impulsividad, poca planificación. |
| Una persona lo hace todo | Problema de reparto. |
| Discuten sin decidir | Falta de facilitación. |
| Prueban pronto | Buen enfoque iterativo. |
| Esperan al final para probar | Riesgo típico de proyecto. |
| Anotan bloqueos | Buena cultura de proceso. |
| Cambian plan tras prueba | Mejora continua. |

### Frases docentes permitidas

Puedes intervenir con preguntas, no con soluciones:

```text
¿Qué tarea estáis haciendo ahora?
¿Qué prueba os dirá si vais bien?
¿Qué bloqueo tenéis?
¿Quién no ha podido participar todavía?
¿Qué haríais si solo quedaran 5 minutos?
```

### Frases a evitar

```text
Pon la base así.
Dobla el papel de esta manera.
Eso no va a funcionar.
Yo lo haría así.
```

---

## 14. Fase 6 — Review y medición

Tiempo:

```text
10 minutos
```

### Objetivo

Mostrar el producto y comprobar si cumple el criterio.

### Protocolo

Por cada equipo:

```text
1. Dejar la torre sin tocar.
2. Contar 10 segundos.
3. Medir altura aproximada si procede.
4. Escuchar explicación breve del equipo.
```

### Preguntas de review

Cada equipo responde en 1 minuto:

```text
1. ¿Cuál era vuestra estrategia?
2. ¿Qué decisión fue más importante?
3. ¿Qué prueba hicisteis?
4. ¿Qué cambiaríais con otro sprint?
```

### Tabla de resultados

Puedes usar esta tabla en pizarra:

| Equipo | Se mantiene 10 s | Altura aprox. | Estrategia | Bloqueo principal |
|---|---|---:|---|---|
| | Sí / No | | | |
| | Sí / No | | | |
| | Sí / No | | | |

### Mensaje importante

```text
Una torre que cae también puede ser una buena evidencia si el equipo sabe explicar qué probó, qué falló y qué mejoraría.
```

---

## 15. Fase 7 — Retrospectiva

Tiempo:

```text
15 minutos
```

### Objetivo

Que el alumnado reflexione sobre el proceso, no solo sobre el producto.

### Guion docente literal

```text
La review mira el producto.

La retrospectiva mira cómo hemos trabajado.

Ahora no se trata de culpar a nadie. Se trata de aprender cómo mejoraríamos en el siguiente sprint.
```

### Plantilla de retrospectiva

Cada equipo completa:

| Pregunta | Respuesta |
|---|---|
| ¿Qué salió bien? | |
| ¿Qué no salió bien? | |
| ¿Qué bloqueo apareció? | |
| ¿Qué haríamos diferente en otro sprint? | |
| ¿Qué aprendemos para MiniJarvis? | |

### Retrospectiva individual rápida

Cada alumno/a escribe:

```text
1. Mi aportación al equipo fue...
2. Una cosa que aprendí sobre trabajar en equipo fue...
3. Una cosa que debo mejorar en el próximo sprint es...
```

---

## 16. Fase 8 — Transferencia a MiniJarvis y cierre

Tiempo:

```text
5 minutos
```

### Guion docente literal

```text
Lo que ha pasado hoy con la torre se parece a lo que pasará con MiniJarvis.

Tendremos una idea, tareas, tiempo limitado, errores, pruebas, revisión y mejora.

La diferencia es que en lugar de papel usaremos código, documentación, pruebas y defensa.
```

### Tabla de transferencia

Puedes escribir:

| Torre de papel | MiniJarvis |
|---|---|
| Torre | Programa/agente |
| Material limitado | Conocimientos y tiempo disponibles |
| Backlog | Tareas del hito |
| Sprint | Periodo de trabajo |
| Review | Demo o entrega |
| Retrospectiva | Mejora del equipo/proceso |
| Bloqueo | Error, duda, fallo técnico |

### Cierre

```text
En la próxima fase empezaremos a preparar la primera versión técnica: un asistente básico por consola.

Pero antes necesitábamos vivir qué significa trabajar por tareas, revisar y mejorar.
```

---

## 17. Hoja de trabajo completa para el alumnado

Puedes copiar esta sección y entregarla, o pedir que la reproduzcan en su cuaderno.

### H0 — Torre de papel y Scrum

#### Equipo

Nombre del equipo:

```text

```

Integrantes:

```text

```

Roles:

| Rol | Persona |
|---|---|
| Facilitador/a | |
| Responsable de backlog | |
| Responsable técnico/a | |
| Responsable de documentación y defensa | |

#### Reglas

```text
1. La torre debe mantenerse en pie al menos 10 segundos.
2. Solo se puede usar el material entregado.
3. Hay que crear backlog antes de construir.
4. Cada persona tiene un rol.
5. Hay review y retrospectiva.
```

#### Backlog

| Nº | Tarea | Responsable | Estado final |
|---:|---|---|---|
| 1 | | | Pendiente / En curso / Hecho / Bloqueado |
| 2 | | | Pendiente / En curso / Hecho / Bloqueado |
| 3 | | | Pendiente / En curso / Hecho / Bloqueado |
| 4 | | | Pendiente / En curso / Hecho / Bloqueado |
| 5 | | | Pendiente / En curso / Hecho / Bloqueado |
| 6 | | | Pendiente / En curso / Hecho / Bloqueado |
| 7 | | | Pendiente / En curso / Hecho / Bloqueado |

#### Bloqueos

| Bloqueo | Qué hicimos |
|---|---|
| | |
| | |

#### Review

Altura aproximada:

```text

```

¿Se mantuvo 10 segundos?

```text
Sí / No
```

Estrategia usada:

```text

```

Decisión más importante:

```text

```

#### Retrospectiva

| Pregunta | Respuesta |
|---|---|
| ¿Qué salió bien? | |
| ¿Qué no salió bien? | |
| ¿Qué bloqueo apareció? | |
| ¿Qué haríamos diferente? | |
| ¿Qué aprendemos para MiniJarvis? | |

#### Reflexión individual

Mi aportación fue:

```text

```

Una cosa que aprendí:

```text

```

Una cosa que debo mejorar:

```text

```

---

## 18. Qué contenidos explicas tú en esta sesión

Debes explicar directamente:

```text
- qué es un sprint;
- qué es un backlog;
- qué es un rol;
- qué es una review;
- qué es una retrospectiva;
- qué es un bloqueo;
- por qué importa el proceso y no solo el producto;
- cómo se conecta la torre con MiniJarvis.
```

No dejes estos conceptos como investigación libre.

Son el marco mínimo para que la actividad funcione.

---

## 19. Qué investiga o descubre el alumnado

El alumnado descubre mediante la actividad:

```text
- qué estrategia de construcción funciona mejor;
- qué tareas necesita su equipo;
- cómo repartir responsabilidades;
- qué pasa cuando no se prueba a tiempo;
- cómo afecta un bloqueo al equipo;
- qué cambiaría en un segundo sprint;
- cómo se parece esto a construir software.
```

Esto encaja con HEXA porque el alumnado explora, ejecuta y comunica dentro de límites claros.

---

## 20. Modelo HEXA aplicado a esta sesión

| Fase | En esta sesión |
|---|---|
| Activar | Recordar MiniJarvis y presentar reto físico. |
| Explorar | Pensar estrategias y tareas del backlog. |
| Ejecutar | Construir la torre durante el sprint. |
| Comunicar | Review del producto. |
| Reflexionar | Retrospectiva de equipo e individual. |
| Ajustar | Transferir aprendizajes a MiniJarvis. |

Frase clave:

```text
HEXA no es investigar sin rumbo. Es aprender haciendo, comunicando y ajustando con una guía clara.
```

---

## 21. Atención a la diversidad y DUA

### Para alumnado con inseguridad alta

Dar rol de documentación o backlog puede ayudar a participar sin exposición técnica inmediata.

### Para alumnado muy dominante

Asignar rol de facilitación con una norma:

```text
Tu misión es que todos hablen, no decidir por todos.
```

### Para alumnado con dificultad de escritura

Permitir evidencias en frases breves, esquemas o dibujo.

### Para alumnado con alta capacidad técnica

Pedir que observe el proceso:

```text
¿Qué decisión del equipo mejoró más el resultado?
```

---

## 22. Gestión de conflictos

Si un alumno domina todo:

```text
Recuerda: el objetivo no es solo construir. Es trabajar como equipo. Necesito escuchar al resto.
```

Si un alumno no participa:

```text
¿Cuál de estas tareas puedes asumir ahora: probar estabilidad, anotar backlog o preparar explicación?
```

Si discuten demasiado:

```text
Tenéis 60 segundos para elegir una opción y probarla. Scrum favorece probar y aprender, no discutir indefinidamente.
```

Si la torre cae:

```text
Perfecto: ahora tenemos información. ¿Qué habéis aprendido para el siguiente intento?
```

---

## 23. Evaluación de la sesión

No conviene poner una nota fuerte.

Uso recomendado:

```text
Diagnóstico inicial + evidencia formativa de Entornos.
```

### Evidencias observables

| Evidencia | Qué demuestra |
|---|---|
| Backlog | Comprensión de tareas y planificación. |
| Roles | Organización inicial del equipo. |
| Review | Comunicación del resultado. |
| Retrospectiva | Mejora continua. |
| Reflexión individual | Conciencia de aportación y mejora. |

### Lista rápida de observación docente

| Equipo | Backlog claro | Roles reales | Prueba durante sprint | Review clara | Retro honesta | Observaciones |
|---|---|---|---|---|---|---|
| | Sí / Parcial / No | Sí / Parcial / No | Sí / No | Sí / Parcial / No | Sí / Parcial / No | |
| | Sí / Parcial / No | Sí / Parcial / No | Sí / No | Sí / Parcial / No | Sí / Parcial / No | |
| | Sí / Parcial / No | Sí / Parcial / No | Sí / No | Sí / Parcial / No | Sí / Parcial / No | |

---

## 24. Adaptación a 45 minutos

Si solo tienes 45 minutos:

| Fase | Tiempo |
|---|---:|
| Presentación reto y roles | 8 min |
| Backlog rápido | 7 min |
| Sprint | 15 min |
| Review | 7 min |
| Retrospectiva y cierre | 8 min |

Reduce:

```text
- número de tareas mínimas a 3;
- retrospectiva a 2 preguntas;
- review a 30 segundos por equipo.
```

Retrospectiva reducida:

```text
1. ¿Qué funcionó?
2. ¿Qué cambiaríamos?
```

---

## 25. Adaptación a 135 minutos

Si tienes 135 minutos:

Añade un segundo sprint.

| Fase | Tiempo |
|---|---:|
| Sprint 1 completo | 55 min |
| Review 1 + retro 1 | 20 min |
| Replanificación | 10 min |
| Sprint 2 | 20 min |
| Review comparativa | 15 min |
| Transferencia a MiniJarvis | 15 min |

Pregunta clave tras el segundo sprint:

```text
¿Qué cambió entre el primer y el segundo intento?
```

Esta versión es muy potente para enseñar mejora continua.

---

## 26. Errores docentes a evitar

```text
[ ] Valorar solo la altura de la torre.
[ ] Dejar construir sin backlog previo.
[ ] Resolver tú el diseño técnico de la torre.
[ ] Permitir que una persona haga todo.
[ ] Saltarte la retrospectiva por falta de tiempo.
[ ] Convertir la sesión en teoría de Scrum.
[ ] No conectar la actividad con MiniJarvis.
[ ] Calificar fuertemente una actividad diagnóstica.
```

---

## 27. Criterio de éxito de la sesión

La sesión ha funcionado si:

```text
[x] Todos los equipos han intentado planificar antes de construir.
[x] Todos han usado roles, aunque sea de forma inicial.
[x] Todos han vivido al menos un sprint.
[x] Todos han hecho review.
[x] Todos han hecho retrospectiva.
[x] El alumnado entiende que el proceso importa.
[x] Hay conexión explícita con MiniJarvis.
```

---

## 28. Cierre verbal recomendado

Puedes terminar diciendo:

```text
Hoy habéis vivido un proyecto pequeño con tiempo limitado, roles, tareas, errores, revisión y mejora.

MiniJarvis funcionará igual: no se hará perfecto a la primera. Lo construiremos por versiones, probando y mejorando.

La próxima vez empezaremos a transformar esta forma de trabajar en una primera versión técnica del asistente.
```

---

## 29. Tarea opcional para casa

Tarea breve:

```text
Escribe 8-10 líneas respondiendo:

1. ¿Qué rol tuviste?
2. ¿Qué aportaste al equipo?
3. ¿Qué bloqueo apareció?
4. ¿Qué aprendiste sobre trabajar por sprints?
5. ¿Qué relación ves con construir MiniJarvis?
```

Tiempo estimado:

```text
10-15 minutos
```

---

## 30. Siguiente sesión recomendada

La siguiente sesión debería iniciar la preparación de H1:

```text
Primer asistente básico por consola.
```

Conexión de apertura para la próxima clase:

```text
En la torre de papel aprendimos a dividir un reto en tareas, probar y mejorar.

Ahora aplicaremos esa idea a código: construiremos la primera versión pequeña de MiniJarvis.
```

<!-- AJUSTE-COBERTURA-CONCEPTOS-32 -->

## Ajuste curricular — cobertura de conceptos de Programación

Este hito queda alineado con el mapa `32-lista-conceptos-programacion-por-tema.md`.

```text
Hito: H0
Temas de referencia: base transversal de Entornos; no introduce todavía conceptos técnicos de Programación evaluables
Foco: preparación metodológica: Scrum de aula, evidencias, roles, comunicación técnica y primer backlog de MiniJarvis
```

Conceptos que deben trabajarse o, como mínimo, quedar conectados con evidencias del alumnado:

- problema
- requisito
- backlog
- evidencia
- review
- retrospectiva
- defensa oral

Criterio docente de cierre:

- El alumnado no solo entrega el producto; debe poder señalar dónde aparece cada concepto en su código, README, pruebas o defensa.
- Si un concepto se marca como ampliación, no penaliza al alumnado que alcance el mínimo, pero sí orienta mejora, recuperación o enriquecimiento.
- La defensa debe incluir al menos una pregunta de comprensión sobre los conceptos nuevos del hito.

