# Índice de cierre — Itinerario MiniJarvis

<!-- HEXA-POLITICA-TODOS-HITOS:START -->

## Política obligatoria: un ciclo HEXA completo en cada hito

Cada hito de MiniJarvis se considera un reto didáctico completo. Por tanto, **H0, H1, H2, H3, H4, H5, H6, H7 y HF deben recorrer y evidenciar las cuatro fases H–E–X–A**. No se aplica HEXA una sola vez al proyecto anual ni se da por cumplido mediante actividades aisladas.

| Fase | Función obligatoria en cada hito | Evidencia mínima |
|---|---|---|
| H — Hecho / reto | Situar el problema, producto, límites y criterios de éxito. | Reformulación del reto y diagnóstico inicial. |
| E — Exploración | Comparar, predecir, formular hipótesis y realizar pruebas iniciales guiadas. | Registro de alternativas, hipótesis, prueba o decisión. |
| X — eXplicación | Formalizar conceptos después de la exploración, con instrucción docente explícita. | Explicación individual conectada con el producto. |
| A — Aplicación | Construir, probar, documentar, defender y mejorar. | Producto funcional o evidencia equivalente, pruebas, documentación y defensa/review. |

La temporalización de cada hito debe reservar, como orientación, un 10–15 % para H, un 20–25 % para E, un 25–30 % para X y un 35–45 % para A. No son cuatro bloques rígidos: una sesión puede cerrar una fase y abrir la siguiente, pero ninguna puede quedar sin tiempo ni evidencia. Los cierres C1/C2 consolidan o recuperan fases; no sustituyen el ciclo del hito.

### Trazabilidad por retos

| Hito | Reto | Expediente HEXA mínimo |
|---|---|---|
| H0 | Organizar y completar una torre de papel mediante un sprint Scrum y transferir lo aprendido a MiniJarvis. | ficha inicial, autoevaluación privada, microprueba, equipos razonados, backlog, torre comprobada, review, retrospectiva, revisión del equipo y aportación individual |
| H1 | Construir el primer MiniJarvis Java por consola, pequeño, ejecutable y defendible. | ficha del reto, salida diseñada, explicación de Main/variables/Scanner, programa, README, evidencia y defensa |
| H2 | Transformar MiniJarvis en un programa interactivo con decisiones, repetición y depuración reproducible. | mapa de comandos, hipótesis de flujo, explicación de condiciones/bucle, menú funcional, pruebas, depuración y defensa |
| H3 | Añadir memoria temporal mediante una colección adecuada y demostrar su comportamiento y límites. | requisitos de memoria, comparación de alternativas, explicación de ArrayList/casos límite, código, pruebas y defensa |
| H4 | Reorganizar MiniJarvis con orientación a objetos y responsabilidades que coincidan con el código y los diagramas. | diagnóstico de Main, alternativas de reparto, explicación POO/encapsulación, clases, diagramas, relación diagrama-código y defensa |
| H5 | Resolver el crecimiento de comandos mediante refactorización segura, contratos simples y código extensible. | diagnóstico del problema, comparación de diseños, explicación de interfaz/Command, refactorización, herramienta nueva, revisión Git y defensa |
| H6 | Conservar memoria e historial entre ejecuciones con ficheros, trazabilidad y tratamiento seguro de errores y datos. | problema reproducido, decisiones de ruta/formato, explicación de persistencia/excepciones/logs, código, prueba en dos ejecuciones, seguridad y defensa |
| H7 | Integrar o simular una ayuda de IA con límites, seguridad, registro y validación humana. | caso de uso y riesgos, clasificación de prompts, explicación de seguridad/validación, simulación o integración segura, registros y defensa |
| HF | Demostrar el aprendizaje del itinerario, localizar carencias y aplicar una mejora o recuperación basada en evidencias. | mapa de evidencias, selección razonada, explicación del progreso, portfolio, demo, defensa, recuperación y plan de mejora |

Regla de evaluación: el producto final por sí solo no acredita el proceso. Si falta una fase, se identifica y recupera su evidencia específica.

<!-- HEXA-POLITICA-TODOS-HITOS:END -->


## Programación + Entornos de Desarrollo — 1.º DAW — Curso 2026/2027

Versión: cierre curricular 1.0 — julio 2026

Documento de cierre del itinerario completo.

---

## 1. Finalidad de este documento

Este índice sirve para localizar rápidamente todos los materiales creados para el proyecto anual MiniJarvis.

El itinerario queda organizado en dos líneas complementarias:

```text
hitos/
```

Material docente, fichas de alumnado, checklists de corrección y plantillas.

```text
99-ejemplos-alumna/
```

Ejemplos completos de Laura, usados como modelo calibrado de entrega.

---

## 2. Documentos base del curso

| Documento | Función |
|---|---|
| `00-mapa-maestro-curso-2026-2027.md` | Visión global del curso y estructura curricular. |
| `02-calendario-hitos-sprints-2026-2027.md` | Calendario de hitos, sprints y evaluaciones. |
| `04A-enunciados-y-entregables-alumnado.md` | Enunciados y entregables por hito. |
| `05-politica-uso-ia-semaforo-registro-defensa.md` | Política de uso de IA, semáforo, registro y defensa. |
| `06-rubricas-hitos.md` | Rúbricas por hito. |
| `07-plantillas-entregables.md` | Plantillas generales. |
| `08-guia-alumnado-proyecto-agente-ia.md` | Guía completa del alumnado. |
| `09-presentacion-alumnado-proyecto-agente-ia.md` | Presentación breve para alumnado. |
| `32-lista-conceptos-programacion-por-tema.md` | Mapa de conceptos de Programación trabajados en cada tema de la carpeta `documentacion/`, con relación a MiniJarvis y criterio para introducir patrones. |
| `300-libro-alumnado-programacion-poo-minijarvis/` | Libro de texto del alumnado con conceptos básicos, casos prácticos MiniJarvis, evidencias de Entornos, patrones cuando procede y revisión editorial. |

---

## 3. Libro de texto del alumnado

Carpeta:

```text
300-libro-alumnado-programacion-poo-minijarvis/
```

Función:

```text
Material de estudio con estructura de libro de texto para que el alumnado repase los conceptos básicos de Programación y Entornos aplicados a MiniJarvis.
```

Capítulos:

| Capítulo | Archivo | Foco |
|---:|---|---|
| 00 | `00-como-usar-este-libro.md` | Cómo estudiar, evidencias, portfolio e IA responsable. |
| 01 | `01-primeros-programas-java.md` | Primer programa, compilación y ejecución. |
| 02 | `02-variables-constantes-entrada-salida.md` | Variables, constantes, Scanner y consola. |
| 03 | `03-decisiones-bucles-menus.md` | Condicionales, bucles y menú de comandos. |
| 04 | `04-pruebas-depuracion-errores.md` | Pruebas manuales, errores y depuración. |
| 05 | `05-colecciones-memoria-temporal.md` | ArrayList y memoria temporal. |
| 06 | `06-programacion-orientada-objetos.md` | Clase, objeto, atributo, método, constructor y responsabilidades. |
| 07 | `07-encapsulacion-responsabilidades-uml.md` | private/public, diagramas y relación diagrama-código. |
| 08 | `08-interfaces-extensibilidad-patrones.md` | Interfaces, extensibilidad, clean code y Command simplificado. |
| 09 | `09-ficheros-persistencia-logs.md` | Ficheros, persistencia, logs y seguridad. |
| 10 | `10-ia-responsable.md` | IA responsable, simulación, prompts y validación humana. |
| 11 | `11-portfolio-defensa-proyecto-final.md` | Portfolio, demo, defensa y cierre. |
| 12 | `12-revision-editorial.md` | Revisión editorial del libro y pendientes opcionales. |

Criterio sobre patrones de diseño:

```text
Los patrones se introducen en el capítulo 08, cuando el alumnado ya ha trabajado POO, encapsulación, responsabilidades e interfaces. Se presenta Command simplificado porque resuelve el problema real de un Agent con demasiados comandos en if/else.
```

---

## 4. Estructura docente por hitos

| Hito | Carpeta | Foco |
|---|---|---|
| H0 | `hitos/h0-torre-papel-scrum/` | Presentación del curso, Scrum mínimo, diagnóstico no calificable, equipos provisionales 3–4, torre, backlog, review y retrospectiva. |
| H1 | `hitos/h1-primer-asistente/` | Primer asistente básico por consola. |
| H2 | `hitos/h2-decisiones-depuracion/` | Menú, decisiones, bucles, pruebas y depuración. |
| H3 | `hitos/h3-memoria-colecciones/` | Memoria temporal con colecciones. |
| H4 | `hitos/h4-agente-orientado-objetos/` | Orientación a objetos, clases y diagramas. |
| H5 | `hitos/h5-extensible-clean-code-patrones/` | Extensibilidad, refactorización, revisión, Git y patrones iniciales. |
| H6 | `hitos/h6-persistente-trazable/` | Persistencia, logs, reproducibilidad y seguridad básica. |
| H7 | `hitos/h7-integracion-ia-responsable/` | Integración IA responsable o simulación robusta. |
| HF | `hitos/hf-presentacion-final-recuperacion-mejora/` | Portfolio final, demo, defensa, recuperación y registro IA final. |

---

## 5. Ejemplos completos de Laura

| Fase | Carpeta de ejemplo |
|---|---|
| H0 | `99-ejemplos-alumna/h0-torre-papel/` |
| H1 | `99-ejemplos-alumna/h1-primer-asistente/` |
| H2 | `99-ejemplos-alumna/h2-decisiones-depuracion/` |
| H3 | `99-ejemplos-alumna/h3-memoria-colecciones/` |
| H4 | `99-ejemplos-alumna/h4-agente-orientado-objetos/` |
| H5 | `99-ejemplos-alumna/h5-extensible-clean-code-patrones/` |
| H6 | `99-ejemplos-alumna/h6-persistente-trazable/` |
| H7 | `99-ejemplos-alumna/h7-integracion-ia-responsable/` |
| HF | `99-ejemplos-alumna/hf-presentacion-final-recuperacion-mejora/` |

---

## 6. Lectura recomendada para el profesorado

Orden recomendado:

1. `00-mapa-maestro-curso-2026-2027.md`
2. `02-calendario-hitos-sprints-2026-2027.md`
3. `05-politica-uso-ia-semaforo-registro-defensa.md`
4. `06-rubricas-hitos.md`
5. `hitos/README.md`
6. Carpetas de `hitos/` según fase.
7. `32-lista-conceptos-programacion-por-tema.md` para localizar qué conceptos oficiales se trabajan en cada tema.
8. Libro de alumnado en `300-libro-alumnado-programacion-poo-minijarvis/`.
9. Ejemplos de Laura en `99-ejemplos-alumna/`.

---

## 7. Lectura recomendada para el alumnado

Orden recomendado:

1. `09-presentacion-alumnado-proyecto-agente-ia.md`
2. `08-guia-alumnado-proyecto-agente-ia.md`
3. Capítulo correspondiente del libro en `300-libro-alumnado-programacion-poo-minijarvis/`.
4. Ficha del hito correspondiente dentro de `hitos/`.
5. Plantillas del hito correspondiente.
6. Ejemplo de Laura solo después de que el alumnado haya intentado su propia entrega o haya cerrado una primera versión defendible.

Política de entrega del libro:

```text
El libro se entrega por capítulos asociados a cada hito, no como dossier completo al inicio del curso.
```

Criterio de publicación al alumnado:

| Momento | Material del libro |
|---|---|
| Inicio / H0-H1 | Capítulo 00 y capítulos 01-02. |
| H2 | Capítulos 03-04. |
| H3 | Capítulo 05. |
| H4 | Capítulos 06-07. |
| H5 | Capítulo 08. |
| H6 | Capítulo 09. |
| H7 | Capítulo 10. |
| HF | Capítulo 11. |

El capítulo 12 queda como revisión editorial docente, no como lectura ordinaria del alumnado.

---

## 8. Criterio de uso de los ejemplos de Laura

Los ejemplos de Laura no deben usarse como solución para copiar.

Uso recomendado:

```text
- mostrar nivel de detalle esperado después del primer intento propio;
- calibrar documentación;
- enseñar cómo justificar decisiones;
- preparar defensas;
- comparar una entrega incompleta con una entrega modelo;
- revisar mejoras posibles sin sustituir la voz del alumnado.
```

Momento recomendado:

```text
Laura se muestra después de la fase de exploración, construcción y primera evidencia del alumnado.
No se presenta como solución inicial del hito.
```

Uso no recomendado:

```text
- entregar el ejemplo como trabajo propio;
- copiar código sin entenderlo;
- sustituir la defensa individual;
- eliminar el proceso de prueba, error y mejora.
```

---

## 9. Seguridad e IA

Reglas transversales:

```text
- No subir secretos.
- No subir .env real.
- No usar datos personales reales en ejemplos.
- Registrar uso de IA.
- Validar respuestas generadas por IA.
- Defender individualmente el trabajo entregado.
```

Regla docente central:

```text
Sin comprensión defendible, no hay evidencia completa de aprendizaje.
```

---

## 10. Estado de cierre del itinerario

El itinerario queda cerrado en esta estructura:

```text
H0 → H1 → H2 → H3 → H4 → H5 → H6 → H7 → HF
```

Cada fase cuenta con:

```text
[x] paquete docente;
[x] ficha o guía para alumnado;
[x] checklist de corrección;
[x] plantillas locales;
[x] ejemplo completo de Laura, salvo H0 con estructura propia de actividad inicial;
[x] verificación ad-hoc durante la construcción.
[x] libro de texto del alumnado con revisión editorial.
```

---

## 11. Próximas acciones posibles

Antes de publicar o versionar:

```text
[x] Homogeneizar versiones como cierre curricular 1.0.
[x] Revisar README del libro del alumnado.
[x] Definir política de entrega del libro por capítulos asociados a cada hito.
[x] Definir que los ejemplos de Laura se muestran después del intento propio del alumnado.
[ ] Maquetar el libro si se va a publicar como PDF o en Moodle.
[ ] Limpiar archivos temporales/swap si procede.
[ ] Crear commit o snapshot del estado final.
```

Criterio de tono final:

```text
Los materiales deben ser autónomos, accionables y defendibles: menos teoría decorativa, más reto MiniJarvis, evidencia, prueba y explicación con palabras propias.
```

<!-- AJUSTE-COBERTURA-CONCEPTOS-32 -->

## Ajuste final — hitos alineados con todos los conceptos de Programación

Después de revisar `32-lista-conceptos-programacion-por-tema.md`, los hitos MiniJarvis quedan modificados para que el itinerario completo cubra los conceptos recopilados.

| Hito | Temas/conceptos reforzados |
|---|---|
| H1 | Tema 1: variables, tipos, literales, operadores, entrada/salida y conversiones. |
| H2 | Temas 1 y 3: condiciones, switch, bucles, depuración y eficiencia básica. |
| H3 | Tema 4: colecciones, listas, recorridos, arrays, Set y Map como ampliación. |
| H4 | Temas 2 y 5: clases, objetos, constructores, métodos, referencias y diagramas. |
| H5 | Temas 5 y 6: tests, TDD, interfaces, polimorfismo, Command simplificado y laboratorio técnico de herencia, Object, Comparable, `instanceof`, clases abstractas y visibilidad. |
| H6 | Temas 5, 6 y puente a 8: excepciones propias/checked/runtime, `throws`, invariantes, persistencia, logs y repositorio como idea. |
| H7 | Temas 5, 6 y 7: records/enums, abstracción, Strategy opcional, Optional, streams y funciones puras. |
| HF | Repaso Temas 1-8: defensa, recuperación y mejora opcional con JavaFX, MVC, arquitectura hexagonal, repositorios, CRUD y transacciones. |

Criterio final:

```text
Al terminar HF, todo concepto del documento 32 debe estar cubierto como núcleo, ampliación, recuperación o mejora defendible.
```

