# Defensa final individual

Alumna: Laura García Martín

---

## Mi aportación

```text
He participado en la evolución de MiniJarvis, especialmente en documentación, pruebas, memoria, diagramas y validación de IA responsable.
```

## Código que puedo explicar

```text
Puedo explicar PersistentMemory de H6 y PromptSafety de H7.
```

## Error que resolví

```text
En H6 aprendí que si la carpeta data no existe, guardar puede fallar. Lo resolví usando Files.createDirectories.
```

## Uso de IA que puedo justificar

```text
He usado IA para entender conceptos, comparar Java con Python y revisar riesgos, pero he verificado el resultado y no he entregado código sin entenderlo.
```

## Pregunta que espero

```text
¿Qué parte no debe recibir nunca una IA?
Respuesta: contraseñas, tokens, API keys, DNI, teléfonos ni datos personales reales.
```

## Respuesta de Laura — cobertura de conceptos de Programación

Relación con `32-lista-conceptos-programacion-por-tema.md`:

```text
HF trabaja principalmente: repaso Temas 1-8.
Foco de aprendizaje: cierre, defensa, recuperación, ampliación final y conexión entre evidencias.
```

Conceptos que Laura debe saber defender en este hito:

- recorrido completo H1-H6: fundamentos, control de flujo, colecciones, POO, extensibilidad, pruebas, persistencia y errores;
- laboratorio de Tema 6: `equals`, `hashCode`, `Comparable`, `instanceof`, clase abstracta, herencia, `super`, `protected`, package-private y polimorfismo;
- decisión de diseño: cuándo usar interfaz/composición y cuándo no conviene forzar herencia;
- recuperación por concepto si falta evidencia de algún tema;
- lambdas, streams y `Optional` como ampliación de Tema 7;
- JavaFX, eventos, MVC, arquitectura hexagonal, caso de uso, repositorio, base de datos, CRUD y transacciones como ampliación de Tema 8 si da tiempo;
- demo con plan B y defensa individual.

Respuesta modelo de Laura:

> En HF conecto mis evidencias con los temas del curso. Puedo explicar desde variables, bucles y colecciones hasta POO, interfaces, patrones, persistencia y seguridad. Del Tema 6 no digo solo “usé interfaces”: también sé reconocer `equals`, `hashCode`, `Comparable`, `instanceof`, clases abstractas y herencia, y puedo justificar por qué algunos conceptos se trabajaron como laboratorio y no entraron en el producto final para mantener MiniJarvis simple y defendible.

Evidencia que Laura debe señalar:

- una evidencia por cada tramo: H1-H2, H3, H4, H5, H6 y H7/HF;
- una recuperación concreta si algún concepto quedó débil;
- una mejora opcional claramente separada del núcleo obligatorio;
- una defensa oral donde pueda localizar el concepto en código, README, prueba o documento.

Pregunta de defensa aconsejada:

> Elige un concepto avanzado que no esté en el producto final y explica cómo lo trabajaste, por qué no lo incorporaste y cómo lo incorporarías sin romper el diseño.

